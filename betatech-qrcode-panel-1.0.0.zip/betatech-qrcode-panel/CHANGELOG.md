# Changelog

## 1.0.0 (2024-08-28)

Initial release.
Submit to Grafana for signature